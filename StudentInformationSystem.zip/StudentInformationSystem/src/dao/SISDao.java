package dao;

public interface SISDao {
	
}
