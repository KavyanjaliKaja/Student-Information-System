package exception;

public class InvalidEnrollmentDataException extends Exception {
    public InvalidEnrollmentDataException(String message) {
        super(message);
    }
}

